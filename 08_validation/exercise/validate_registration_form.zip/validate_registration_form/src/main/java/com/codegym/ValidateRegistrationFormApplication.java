package com.codegym;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ValidateRegistrationFormApplication {

    public static void main(String[] args) {
        SpringApplication.run(ValidateRegistrationFormApplication.class, args);
    }

}
